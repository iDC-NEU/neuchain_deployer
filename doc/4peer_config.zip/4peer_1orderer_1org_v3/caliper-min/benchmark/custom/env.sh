BLOCK_SIZE=200
NETWORK_DIR="../../network/fabric/simpledocker"
DOCKER_COMPOSE_PATH="${NETWORK_DIR}/docker-compose.yaml"
NETWORK_SETUP_PATH="${NETWORK_DIR}/setup.json" 
ORDERER_LOG_PATH="${NETWORK_DIR}/log/orderer.log"
PEER_LOG_PATH="${NETWORK_DIR}/log/orderer.log"
RESULT_DIR=result